"""4단계: 그린존 1차 후보 확정 (팀 결정 2026-10-19)

후보 15곳을 고른 뒤, 팀 결정에 따라 어린이공원 3곳과 같은 이름 중복 공터 1곳을 빼서 11곳이 된다.

필수 조건 (모두 만족)
  1. 어린이·노인·장애인 보호구역 대상시설 반경 200m 밖
  2. 5t 수거차가 들어갈 도로 유효폭 7m 이상
       (등록폭 7m 이상이면 등록폭, 아니면 min(등록폭, 실폭도로 실측폭). 노상주차장은 주차면 2.5m 제외)
  3. 그린존 설치 부지 확보 — 아래 우선순위로 확보
       ① 공원·공영주차장 (02_public_sites.py 결과 중 합격·조건부 합격)
       ② 구 소유 공공시설 부지 (주민센터·파출소·구립시설)
       ③ 도로변 대형 공터: 공터 추정 500㎡ 이상 + 접한 도로 유효폭 12m 이상 (03_roadside_lots.py 결과)
  목표 15곳 = ① + ② + ③(면적 큰 순, 다른 후보와 80m 이상 간격)

실행 순서: python 02_public_sites.py → python 03_roadside_lots.py → python 04_select_candidates.py
출력: build/final/ 폴더
"""
import os
import json
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import LineString, Point
from shapely.ops import unary_union, nearest_points

TARGET = 15
PROTECT_R = 200
ROAD_SAFE = 7.0
LOT_MIN_M2 = 500
LOT_ROAD_MIN = 12.0
MIN_SPACING = 60          # 후보 간 최소 간격 (80m에서는 14곳 → 60m로 조정)
FACILITY_KEYWORDS = ["주민센터", "파출소", "푸드뱅크"]   # 구 소유 공공시설 (건물명 기준)
FACILITY_ROAD_SEARCH = 15
CRS_M = 5186
OUT = "build/final"
os.makedirs(OUT, exist_ok=True)

dong = gpd.read_file("build/shinwol1_boundary_5186.geojson").to_crs(CRS_M).geometry.iloc[0]
roads = gpd.read_file("data/raw/emap/11470/TL_SPRD_MANAGE.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
roads = roads[roads.intersects(dong.buffer(300))].copy()
roads["ROAD_BT"] = pd.to_numeric(roads["ROAD_BT"], errors="coerce")
rw = gpd.read_file("data/raw/emap/11470/TL_SPRD_RW.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
rw_u = unary_union(rw[rw.intersects(dong.buffer(300))].geometry)
bld = gpd.read_file("data/raw/emap/11470/TL_SPBD_BULD.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
bld = bld[bld.intersects(dong.buffer(80))].copy()
prot = gpd.read_file("build/web/protection_facilities.geojson").to_crs(CRS_M)
rn_name = dict(zip(roads["RN_CD"], roads["RN"]))
allroads = gpd.read_file("data/raw/emap/11470/TL_SPRD_MANAGE.shp", encoding="cp949", ignore_geometry=True)
rn_name.update(dict(zip(allroads["RN_CD"], allroads["RN"])))


def measured_width(line, pt, span=20, step=5, half=40):
    if line.geom_type == "MultiLineString":
        line = min(line.geoms, key=lambda g: g.distance(pt))
    s0 = line.project(pt)
    ws = []
    for s in np.arange(s0 - span, s0 + span + 0.1, step):
        if s < 1 or s > line.length - 1:
            continue
        a, b = line.interpolate(s - 1), line.interpolate(s + 1)
        dx, dy = b.x - a.x, b.y - a.y
        n = (dx * dx + dy * dy) ** 0.5
        c = line.interpolate(s)
        px, py = -dy / n * half, dx / n * half
        cut = LineString([(c.x - px, c.y - py), (c.x + px, c.y + py)]).intersection(rw_u)
        hit = [g for g in getattr(cut, "geoms", [cut]) if g.length > 0 and g.distance(c) < 0.5]
        if hit:
            ws.append(hit[0].length)
    return round(float(np.median(ws)), 1) if ws else None


def nearest_prot(geom):
    d = prot.distance(geom)
    i = d.idxmin()
    return f"{prot.at[i, '시설명']}({prot.at[i, '구분']})", int(round(d.min()))


def address_near(pt, max_d=60, prefer_rn=None):
    """가장 가까운 건물의 도로명·지번 주소 (후보 위치 '인근' 주소로 사용).
    prefer_rn이 주어지면 그 도로에 주소를 둔 건물을 우선한다."""
    d = bld.distance(pt)
    cand = d[d <= max_d]
    if len(cand) == 0:
        return "", ""
    if prefer_rn:
        same = cand[[rn_name.get(bld.at[i, "RN_CD"], "") == prefer_rn for i in cand.index]]
        if len(same):
            cand = same
    i = cand.idxmin()
    b = bld.loc[i]
    rn = rn_name.get(b["RN_CD"], "")
    road_no = f"{int(b['BULD_MNNM'])}" + (f"-{int(b['BULD_SLNO'])}" if int(b["BULD_SLNO"] or 0) else "")
    jibun = f"{int(b['LNBR_MNNM'])}" + (f"-{int(b['LNBR_SLNO'])}" if int(b["LNBR_SLNO"] or 0) else "")
    return f"서울특별시 양천구 {rn} {road_no}".strip(), f"서울특별시 양천구 신월동 {jibun}"


# ---- ① 공원·공영주차장 ------------------------------------------------------------
pub_all = gpd.read_file("build/web/greenzone_candidates_all.geojson").to_crs(CRS_M)
pub_all = pub_all[pub_all["후보군"] == "공공부지"].copy()
pub = pub_all[pub_all["최종판정"].isin(["합격", "조건부 합격"])].copy()
pub_rej = pub_all[~pub_all.index.isin(pub.index)]
rows = []
for _, r in pub.iterrows():
    cond = []
    if r["c2_부지"] == "조건부":
        cond.append("어린이공원: 놀이공간과 분리된 도로변 가장자리에만 설치")
    rows.append(dict(후보군="① 공원·공영주차장", 이름=r["이름"], 부지유형=r["부지유형"], 세부유형=r["세부유형"],
                     부지면적_m2=r["면적_m2"], 면적근거="공원면적" if r["부지유형"] == "공원" else "주차면수x12.5㎡ 추정",
                     접도_도로=r["접도_도로"], 등록폭_m=r["등록폭_m"], 실측폭_m=r["실측폭_m"], 유효폭_m=r["유효폭_m"],
                     폭_판정근거=r["폭_판정근거"], 조건1_사유=r["c1_사유"], 조건2_사유=r["c3_사유"], 조건3_사유=r["c2_사유"],
                     조건부_내용=" / ".join(cond), 확인필요=r["확인필요"] if isinstance(r["확인필요"], str) else "",
                     지번주소=r["주소"], geometry=r.geometry))

# ---- ② 구 소유 공공시설 ------------------------------------------------------------
fac = bld[bld.within(dong) & bld["BULD_NM"].fillna("").str.contains("|".join(FACILITY_KEYWORDS))].copy()
fac_log = []
for _, b in fac.iterrows():
    g = b.geometry
    name = b["BULD_NM"]
    pname, pd_ = nearest_prot(g)
    near = roads[roads.distance(g) <= FACILITY_ROAD_SEARCH]
    best = None
    for j, rr in near.iterrows():
        bt = float(rr["ROAD_BT"])
        mw = measured_width(rr.geometry, g.centroid)
        eff, basis = (bt, "등록폭 기준") if bt >= ROAD_SAFE else ((min(bt, mw) if mw else bt), "등록·실측 중 작은 값")
        if best is None or eff > best[0]:
            best = (eff, rr["RN"], bt, mw, basis, j)
    ok1 = pd_ > PROTECT_R
    ok2 = best is not None and best[0] >= ROAD_SAFE
    fac_log.append(dict(시설=name, 보호시설까지_m=pd_, 접도_도로=best[1] if best else "", 유효폭_m=best[0] if best else None,
                        결과="채택" if ok1 and ok2 else ("탈락: 보호구역" if not ok1 else "탈락: 도로폭 7m 미만")))
    if not (ok1 and ok2):
        continue
    eff, rn, bt, mw, basis, j = best
    front = nearest_points(g, roads.at[j, "geometry"])[0]      # 도로 쪽 건물 가장자리
    road_addr, jibun = address_near(g.centroid)
    rows.append(dict(후보군="② 구 소유 공공시설", 이름=name, 부지유형="공공시설", 세부유형=b["BDTYP_CD"],
                     부지면적_m2=round(g.area), 면적근거="건물 바닥면적 (부지는 앞마당·주차공간)",
                     접도_도로=rn, 등록폭_m=bt, 실측폭_m=mw, 유효폭_m=eff, 폭_판정근거=basis,
                     조건1_사유=f"반경 {PROTECT_R}m 안 보호시설 없음 (최근접 {pname} {pd_}m)",
                     조건2_사유=f"{rn}(등록 {bt:g}m / 실측 {mw if mw else '불가'}m, {basis}) → 유효 {eff:g}m ≥ {ROAD_SAFE:g}m",
                     조건3_사유="구 소유 공공시설 부지 - 앞마당·주차공간 활용",
                     조건부_내용="시설 앞마당·주차공간 크기와 시설 운영 협의 필요",
                     확인필요="설치 가능한 마당·주차공간이 있는지 로드뷰 확인",
                     도로명주소=road_addr, 지번주소=jibun, geometry=front))

# ---- ③ 도로변 대형 공터 ------------------------------------------------------------
ev = gpd.read_file("build/work/roadside_all_points.geojson").to_crs(CRS_M)
lots = gpd.read_file("build/work/open_space_all.geojson").to_crs(CRS_M).set_index("lot_id")
big = ev[(ev["세부유형"] == "공터형") & (ev["공터면적_m2"] >= LOT_MIN_M2) & (ev["유효폭_m"] >= LOT_ROAD_MIN)].copy()
big = big.sort_values(["공터면적_m2", "유효폭_m"], ascending=False).drop_duplicates("lot_id")   # 공터당 1곳
n_lot_pool = len(big)
need = TARGET - len(rows)
taken = [r["geometry"] for r in rows]
chosen_lots = []
for _, r in big.iterrows():
    if len(chosen_lots) >= need:
        break
    if nearest_prot(r.geometry)[1] <= PROTECT_R:      # 최종 표시 위치 기준으로 보호구역 재검사
        continue
    if all(r.geometry.distance(g) >= MIN_SPACING for g in taken):
        chosen_lots.append(r)
        taken.append(r.geometry)
for r in chosen_lots:
    road_addr, jibun = address_near(r.geometry, prefer_rn=r["접도_도로"])
    road_addr += " 인근"
    rows.append(dict(후보군="③ 도로변 대형 공터", 이름=f"{r['접도_도로']} 도로변 공터", 부지유형="도로변 공터", 세부유형="공터 추정",
                     부지면적_m2=r["공터면적_m2"], 면적근거="건물·도로·골목을 뺀 빈 공간 면적(추정)",
                     접도_도로=r["접도_도로"], 등록폭_m=r["등록폭_m"], 실측폭_m=r["실측폭_m"], 유효폭_m=r["유효폭_m"],
                     폭_판정근거=r["폭_판정근거"],
                     조건1_사유=f"반경 {PROTECT_R}m 안 보호시설 없음 (최근접 {r['최근접_보호시설']} {r['보호시설까지_m']}m)",
                     조건2_사유=f"{r['접도_도로']}(등록 {r['등록폭_m']:g}m / 실측 {r['실측폭_m']}m, {r['폭_판정근거']}) → 유효 {r['유효폭_m']:g}m ≥ {LOT_ROAD_MIN:g}m, 교차로에서 {r['교차로까지_m']}m",
                     조건3_사유=f"도로변 빈 공간 약 {r['공터면적_m2']:,.0f}㎡ ≥ {LOT_MIN_M2}㎡",
                     조건부_내용="공터 소유(사유지·국공유지)와 현재 용도 확인 필요",
                     확인필요="빈 공간이 사유지 마당·주차장이 아닌지 로드뷰·토지이음 확인",
                     도로명주소=road_addr, 지번주소=jibun, lot_id=int(r["lot_id"]), geometry=r.geometry))

final = gpd.GeoDataFrame(rows, crs=CRS_M)
# 팀 결정 (2026-10-19 20:20): 어린이공원은 아이들 공간이므로 후보에서 제외. 나머지 후보 선정은 그대로 유지
EXCLUDE = {"곰달래공원": "어린이공원 제외 (팀 결정)", "반곡공원": "어린이공원 제외 (팀 결정)", "신월공원": "어린이공원 제외 (팀 결정)"}
excluded_log = [f"{n}: {why}" for n, why in EXCLUDE.items() if n in set(final["이름"])]
final = final[~final["이름"].isin(EXCLUDE)].reset_index(drop=True)
# 팀 결정 (2026-10-19 20:23): 같은 이름의 후보는 하나만 유지 (면적이 큰 곳). 곰달래로5길 도로변 공터 2곳 → 1곳
final = final.sort_values("부지면적_m2", ascending=False)
dups = final[final.duplicated("이름", keep="first")]
excluded_log += [f"{r['이름']} ({r['도로명주소']}, {r['부지면적_m2']:,.0f}㎡): 같은 이름 중복 - 면적 큰 곳만 유지 (팀 결정)" for _, r in dups.iterrows()]
final = final.drop(dups.index).sort_index().reset_index(drop=True)
for i, r in final.iterrows():                       # 공공부지는 인근 도로명주소 보강
    if not isinstance(r.get("도로명주소"), str) or not r.get("도로명주소"):
        final.at[i, "도로명주소"] = address_near(r.geometry, prefer_rn=r["접도_도로"])[0] + " 인근"
final["판정"] = np.where(final["조건부_내용"].fillna("") == "", "합격", "조건부 합격")
final["보호시설까지_m"] = [nearest_prot(g)[1] for g in final.geometry]
final["최근접_보호시설"] = [nearest_prot(g)[0] for g in final.geometry]
final.insert(0, "번호", range(1, len(final) + 1))
final.insert(0, "id", [f"G{i:02d}" for i in range(1, len(final) + 1)])
w = final.to_crs(4326)
final["위도"], final["경도"] = w.geometry.y.round(6), w.geometry.x.round(6)
final["네이버지도"] = [f"https://map.naver.com/p?c={x},{y},18,0,0,0,dh" for x, y in zip(final["경도"], final["위도"])]

cols = ["id", "번호", "이름", "후보군", "판정", "조건부_내용", "부지유형", "세부유형", "부지면적_m2", "면적근거",
        "도로명주소", "지번주소", "위도", "경도", "접도_도로", "등록폭_m", "실측폭_m", "유효폭_m", "폭_판정근거",
        "최근접_보호시설", "보호시설까지_m", "조건1_사유", "조건2_사유", "조건3_사유", "확인필요", "네이버지도"]
final[cols].to_csv(f"{OUT}/greenzone_final.csv", index=False, encoding="utf-8-sig")
final[cols + ["geometry"]].to_crs(4326).to_file(f"{OUT}/greenzone_final.geojson", driver="GeoJSON")

# 보조 레이어
used_lots = lots.loc[[int(x) for x in final["lot_id"].dropna()]].reset_index()   # 최종 후보에 남은 공터만
used_lots = used_lots.merge(final[["id", "lot_id"]].dropna(), on="lot_id", how="left")
used_lots.to_crs(4326).to_file(f"{OUT}/layer_open_space.geojson", driver="GeoJSON")
for f in ["protection_zones", "protection_facilities", "shinwol1_boundary"]:
    gpd.read_file(f"build/web/{f}.geojson").to_file(f"{OUT}/layer_{f}.geojson", driver="GeoJSON")
rl = gpd.read_file("build/web/roads_shinwol1.geojson")
rl.to_file(f"{OUT}/layer_roads.geojson", driver="GeoJSON")

# 판정 과정 기록 (설명용)
funnel = {
    "공원·공영주차장_신월1동내": int(len(pub_all)),
    "공원·공영주차장_통과": int(len(pub)),
    "공원·공영주차장_탈락": [f"{r['이름']}: {r['판정요약']}" for _, r in pub_rej.iterrows()],
    "공공시설_검토": fac_log,
    "도로변_대형공터_후보풀(공터 수)": int(n_lot_pool),
    "도로변_대형공터_채택": len(chosen_lots),
    "팀결정_제외": excluded_log,
    "최종": int(len(final)),
}
json.dump(funnel, open(f"{OUT}/_funnel.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
print(json.dumps(funnel, ensure_ascii=False, indent=1, default=str))
print(final[["id", "이름", "후보군", "판정", "유효폭_m", "부지면적_m2", "보호시설까지_m", "도로명주소"]].to_string(index=False))
