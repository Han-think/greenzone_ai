"""6단계: 팀이 정리한 엑셀(greenzone_1st.xlsx)을 원본으로 1차 후보군 결과물 생성

입력 : data/team/greenzone_1st.xlsx  (시트1: 1차 후보군 11곳, 시트2: 선정 기준 설명)
       build/final/layer_*.geojson (4단계에서 만든 보조 레이어)
       ※ 팀 엑셀이 코드 결과와 일치하는지는 5단계(05_team_table.py)에서 검증
출력 : outputs/greenzone1st/ 폴더
       greenzone1st.geojson, greenzone1st.csv, greenzone1st_map.html, greenzone1st_map.png,
       greenzone1st.md, greenzone1st_layer_*.geojson, greenzone1st.xlsx(원본 사본)
"""
import os
import json
import shutil
import logging
import pandas as pd
import geopandas as gpd

SRC = "data/team/greenzone_1st.xlsx"
OUT = "outputs/greenzone1st"
os.makedirs(OUT, exist_ok=True)

# ---- 1. 엑셀 읽기 (엑셀 값을 그대로 쓰고, 열 이름 공백만 정리) -------------------------
xl = pd.ExcelFile(SRC)
df = pd.read_excel(xl, xl.sheet_names[0])
df.columns = [c.strip() for c in df.columns]
df = df.apply(lambda col: col.str.strip() if col.dtype == object else col)   # 셀 앞뒤 공백만 정리
for c in ["위도", "경도", "부지면적_㎡", "등록폭_m", "유효폭_m", "보호시설과의 거리_m"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
df["번호"] = pd.to_numeric(df["번호"], errors="coerce").astype(int)
df = df.where(df.notna(), None)
gdf = gpd.GeoDataFrame(df, geometry=gpd.points_from_xy(df["경도"], df["위도"]), crs=4326)

gdf.to_file(f"{OUT}/greenzone1st.geojson", driver="GeoJSON")
df.to_csv(f"{OUT}/greenzone1st.csv", index=False, encoding="utf-8-sig")
shutil.copy(SRC, f"{OUT}/greenzone1st.xlsx")

# ---- 2. 보조 레이어 (이름만 greenzone1st로) ------------------------------------------------
layers = {"boundary": "layer_shinwol1_boundary", "protection_zones": "layer_protection_zones",
          "protection_facilities": "layer_protection_facilities", "roads": "layer_roads"}
for new, old in layers.items():
    gpd.read_file(f"build/final/{old}.geojson").to_file(f"{OUT}/greenzone1st_layer_{new}.geojson", driver="GeoJSON")
lots = gpd.read_file("build/final/layer_open_space.geojson")
lots = lots[lots["id"].isin(gdf["id"])].merge(df[["id", "이름", "위성지도로 2차 확인"]], on="id", how="left")
lots.to_file(f"{OUT}/greenzone1st_layer_open_space.geojson", driver="GeoJSON")

# ---- 3. PNG 지도 ----------------------------------------------------------------------------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
for f in font_manager.findSystemFonts():
    if any(k in f for k in ("NotoSansCJK", "malgun", "Malgun", "Nanum", "AppleGothic")):
        font_manager.fontManager.addfont(f)
names = {f.name for f in font_manager.fontManager.ttflist}
plt.rcParams["font.family"] = next((n for n in ("Malgun Gothic", "AppleGothic", "Noto Sans CJK KR", "NanumGothic") if n in names), "sans-serif")

GROUP = {"공영주차장": ("#1b8a4a", "o"), "공공시설": ("#2f6db5", "s"), "도로변 공터": ("#8e44ad", "D")}
M = 5186
g = gdf.to_crs(M)
bd = gpd.read_file(f"{OUT}/greenzone1st_layer_boundary.geojson").to_crs(M)
pz = gpd.read_file(f"{OUT}/greenzone1st_layer_protection_zones.geojson").to_crs(M)
pf = gpd.read_file(f"{OUT}/greenzone1st_layer_protection_facilities.geojson").to_crs(M)
rd = gpd.read_file(f"{OUT}/greenzone1st_layer_roads.geojson").to_crs(M)
lt = lots.to_crs(M)

fig, ax = plt.subplots(figsize=(10, 11))
pz.plot(ax=ax, color="#f3c2bb", alpha=0.45, linewidth=0)
rd[rd["폭등급"] != "7m 이상"].plot(ax=ax, color="#d5d5d5", linewidth=0.7)
rd[rd["폭등급"] == "7m 이상"].plot(ax=ax, color="#7fa6d6", linewidth=2.2)
lt.plot(ax=ax, color="#d7bde2", edgecolor="#8e44ad", linewidth=0.6)
bd.boundary.plot(ax=ax, color="#1b6b4a", linewidth=2.4)
pf.plot(ax=ax, color="#b3261e", marker="^", markersize=40)
for grp, (col, mk) in GROUP.items():
    s = g[g["부지유형"] == grp]
    if len(s):
        s.plot(ax=ax, color=col, marker=mk, markersize=230, edgecolor="white", linewidth=1.5, zorder=5)
for _, r in g.iterrows():
    ax.annotate(str(r["번호"]), (r.geometry.x, r.geometry.y), ha="center", va="center", fontsize=8.5,
                color="white", fontweight="bold", zorder=6)
    ax.annotate(r["이름"].replace(" 공영주차장", " 주차장"), (r.geometry.x, r.geometry.y), xytext=(10, 6),
                textcoords="offset points", fontsize=7.5, zorder=6,
                bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none", alpha=0.75))
minx, miny, maxx, maxy = bd.buffer(90).total_bounds
ax.set_xlim(minx, maxx); ax.set_ylim(miny, maxy); ax.set_axis_off()
h = [Line2D([], [], marker=mk, ls="", color=col, mec="white", ms=12, label=f"{grp} ({(g['부지유형'] == grp).sum()})")
     for grp, (col, mk) in GROUP.items()]
h += [Line2D([], [], marker="s", ls="", color="#d7bde2", mec="#8e44ad", ms=11, label="공터 공간"),
      Line2D([], [], color="#7fa6d6", lw=2.2, label="도로폭 7m 이상"),
      Line2D([], [], marker="^", ls="", color="#b3261e", ms=8, label="보호구역 대상시설"),
      Line2D([], [], marker="s", ls="", color="#f3c2bb", ms=11, label="보호구역 반경 200m (제외)"),
      Line2D([], [], color="#1b6b4a", lw=2.4, label="신월1동 경계")]
ax.legend(handles=h, loc="lower left", fontsize=8, frameon=True)
ax.set_title(f"신월1동 그린존 1차 후보군 {len(g)}곳\n차량 접근성(도로 7m 이상) · 안전성(보호구역 200m 밖, 어린이공원 제외) · 부지 확보", fontsize=11)
plt.tight_layout()
plt.savefig(f"{OUT}/greenzone1st_map.png", dpi=170)

# ---- 4. HTML 지도 (Leaflet + OpenStreetMap) ---------------------------------------------------
def gj(x):
    return json.loads(x.to_crs(4326).to_json())

data = {"c": gj(gdf), "b": gj(bd), "z": gj(pz), "f": gj(pf), "l": gj(lots)}
colors = {k: v[0] for k, v in GROUP.items()}
html = """<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>신월1동 그린존 1차 후보군</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
html,body{margin:0;height:100%;font-family:'Malgun Gothic','Apple SD Gothic Neo',sans-serif}
#map{position:absolute;inset:0 0 0 340px}
#side{position:absolute;top:0;left:0;bottom:0;width:340px;overflow:auto;background:#f7faf8;border-right:1px solid #d9e4dd;padding:14px;box-sizing:border-box}
h1{font-size:16px;margin:0 0 4px;color:#1b6b4a} .sub{font-size:12px;color:#555;margin-bottom:10px;line-height:1.5}
.item{background:#fff;border:1px solid #e1e8e4;border-radius:8px;padding:8px 10px;margin:6px 0;cursor:pointer;font-size:12.5px}
.item:hover{border-color:#1b6b4a}
.num{display:inline-block;width:20px;height:20px;border-radius:50%;color:#fff;text-align:center;line-height:20px;font-weight:bold;font-size:11px;margin-right:6px}
.tag{font-size:11px;color:#666} .sat{color:#6c3483;font-size:11px}
.leaflet-popup-content{font-size:12.5px;line-height:1.45}
.pin{border-radius:50%;color:#fff;font-weight:bold;text-align:center;border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.4)}
.legend{background:#fff;padding:6px 8px;border-radius:6px;font-size:12px;line-height:1.7;box-shadow:0 1px 4px rgba(0,0,0,.2)}
.legend i{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:5px;vertical-align:-1px}
@media (max-width:700px){#side{width:100%;height:38%;bottom:auto;border-right:0;border-bottom:1px solid #d9e4dd}#map{inset:38% 0 0 0}}
</style></head><body>
<div id="side"><h1>신월1동 그린존 1차 후보군 __N__곳</h1>
<div class="sub">① 차량 접근성: 도로 유효폭 7m 이상<br>② 안전성: 보호구역 200m 밖, 어린이공원 제외<br>③ 부지 확보: 공영주차장·공공시설·도로변 공터<br><span class="tag">현장 확인 전 제안이며 실제 배출 장소가 아닙니다.</span></div>
<div id="list"></div></div><div id="map"></div>
<script>
const D=__DATA__, C=__COLORS__;
const map=L.map('map');
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
L.geoJSON(D.z,{style:{color:'#d9534f',weight:0,fillOpacity:.15},interactive:false}).addTo(map);
L.geoJSON(D.l,{style:{color:'#8e44ad',weight:1,fillColor:'#d7bde2',fillOpacity:.55}}).addTo(map);
const bd=L.geoJSON(D.b,{style:{color:'#1b6b4a',weight:3,fill:false}}).addTo(map);
L.geoJSON(D.f,{pointToLayer:(f,ll)=>L.circleMarker(ll,{radius:5,color:'#b3261e',fillOpacity:1}).bindTooltip(f.properties['시설명']+' ('+f.properties['구분']+')')}).addTo(map);
const v=x=>(x===null||x===undefined)?'':x;
function popup(p){return `<b>${p['번호']}. ${p['이름']}</b><br><span class="tag">${p['부지유형']} · ${p['세부유형']} · ${p['판정']}</span><br>`+
 (p['위성지도로 2차 확인']?`<span class="sat">위성지도 2차 확인: ${p['위성지도로 2차 확인']}</span><br>`:'')+
 `<hr style="border:0;border-top:1px solid #eee">① ${v(p['조건1_사유'])}<br>② ${v(p['조건2_사유'])}<br>③ ${v(p['조건3_사유'])}<br>`+
 `<span class="tag">${v(p['도로명주소'])||v(p['지번주소'])}<br>${p['위도']}, ${p['경도']}</span>`;}
const markers={};
L.geoJSON(D.c,{pointToLayer:(f,ll)=>{const p=f.properties,col=C[p['부지유형']]||'#555';
 const m=L.marker(ll,{icon:L.divIcon({className:'',html:`<div class="pin" style="background:${col};width:24px;height:24px;line-height:24px">${p['번호']}</div>`,iconSize:[28,28],iconAnchor:[14,14]})}).bindPopup(popup(p),{maxWidth:330});
 markers[p['번호']]=m;return m;}}).addTo(map);
map.fitBounds(bd.getBounds(),{padding:[20,20]});
const lg=L.control({position:'bottomright'});lg.onAdd=()=>{const d=L.DomUtil.create('div','legend');
 d.innerHTML=Object.entries(C).map(([k,c])=>`<i style="background:${c}"></i>${k}`).join('<br>')+'<br><i style="background:#b3261e"></i>보호구역 대상시설';return d;};lg.addTo(map);
const list=document.getElementById('list');
D.c.features.forEach(f=>{const p=f.properties,col=C[p['부지유형']]||'#555';const d=document.createElement('div');d.className='item';
 d.innerHTML=`<span class="num" style="background:${col}">${p['번호']}</span><b>${p['이름']}</b><br><span class="tag">${p['부지유형']} · 도로 ${p['유효폭_m']}m · 부지 ${Number(p['부지면적_㎡']).toLocaleString()}㎡</span>`+(p['위성지도로 2차 확인']?`<br><span class="sat">${p['위성지도로 2차 확인']}</span>`:'');
 d.onclick=()=>{const m=markers[p['번호']];map.setView(m.getLatLng(),18);m.openPopup();};list.appendChild(d);});
</script></body></html>"""
html = html.replace("__N__", str(len(gdf))).replace("__DATA__", json.dumps(data, ensure_ascii=False)).replace("__COLORS__", json.dumps(colors, ensure_ascii=False))
open(f"{OUT}/greenzone1st_map.html", "w", encoding="utf-8").write(html)

# ---- 5. 기준 설명 시트 읽기 (md에 그대로 인용) --------------------------------------------
crit = pd.read_excel(xl, xl.sheet_names[1], header=None).iloc[:, 1].dropna().astype(str).tolist()
json.dump(crit, open("build/work/criteria_sheet.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(len(gdf), "곳 →", OUT)
