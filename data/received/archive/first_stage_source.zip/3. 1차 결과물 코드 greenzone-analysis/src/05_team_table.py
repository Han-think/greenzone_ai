"""5단계: 4단계 결과 → 팀 1차 후보군 표 (팀 수동 수정 반영 + 팀 엑셀과 대조 검증)

4단계 코드 결과(build/final/greenzone_final.csv)에서 팀이 엑셀로 손본 내용을
data/team/manual_edits.csv 에 칸 단위로 기록해 두고, 이 단계에서 그대로 적용한다.
  - 열 정리 : 개발·발표에 필요 없는 열 삭제, 열 이름 변경, '위성지도로 2차 확인' 열 추가
  - 칸 수정 : manual_edits.csv 의 (id, 열, 수정값, 사유) 를 적용
                예) 위성지도 2차 확인 후 '조건부 합격' → '합격', 주소 표기 정리, 지번 수정
마지막에 결과를 data/team/greenzone_1st.xlsx(팀 정리본)와 한 칸씩 비교해
다르면 어떤 칸이 다른지 출력하고 멈춘다. → 코드와 팀 엑셀이 어긋나지 않게 지키는 장치

출력: build/final/greenzone_1st_generated.xlsx
"""
import sys
import pandas as pd

SRC = "build/final/greenzone_final.csv"
EDITS = "data/team/manual_edits.csv"
TEAM = "data/team/greenzone_1st.xlsx"
OUT = "build/final/greenzone_1st_generated.xlsx"

DROP = ["후보군", "조건부_내용", "실측폭_m", "폭_판정근거", "확인필요", "네이버지도"]
RENAME = {"부지면적_m2": "부지면적_㎡", "면적근거": "면적 산출 근거", "보호시설까지_m": "보호시설과의 거리_m"}
ORDER = ["id", "번호", "이름", "부지유형", "세부유형", "판정", "부지면적_㎡", "면적 산출 근거", "도로명주소", "지번주소",
         "위성지도로 2차 확인", "위도", "경도", "접도_도로", "등록폭_m", "유효폭_m", "최근접_보호시설",
         "보호시설과의 거리_m", "조건1_사유", "조건2_사유", "조건3_사유"]

df = pd.read_csv(SRC, dtype=str)
df = df.drop(columns=[c for c in DROP if c in df.columns]).rename(columns=RENAME)
df["위성지도로 2차 확인"] = ""
df = df[ORDER].set_index("id")

ed = pd.read_csv(EDITS, dtype=str).fillna("")
for _, e in ed.iterrows():
    cur = "" if pd.isna(df.at[e["id"], e["열"]]) else str(df.at[e["id"], e["열"]]).strip()
    if cur != e["코드값"].strip():
        sys.exit(f"✖ 수정 기록이 코드 결과와 맞지 않음: {e['id']} / {e['열']} (코드값 '{cur}' ≠ 기록 '{e['코드값']}'). "
                 "1~4단계 기준이 바뀌었다면 manual_edits.csv 를 다시 정리해야 합니다.")
    df.at[e["id"], e["열"]] = e["수정값"]
df = df.reset_index()
df.to_excel(OUT, index=False)
print(f"수동 수정 {len(ed)}칸 적용 ({ed['열'].value_counts().to_dict()})")

# ---- 팀 엑셀과 대조 ------------------------------------------------------------------------
team = pd.read_excel(TEAM, sheet_name=0, dtype=str)
team.columns = [c.strip() for c in team.columns]


def norm(v):
    s = "" if pd.isna(v) else str(v).strip()
    try:
        return f"{float(s):.6f}"
    except ValueError:
        return s


diff = []
if list(team.columns) != list(df.columns):
    diff.append(("열 구성", "", str(list(df.columns)), str(list(team.columns))))
for i in range(max(len(team), len(df))):
    for c in df.columns:
        a = norm(df.at[i, c]) if i < len(df) else "(없음)"
        b = norm(team.at[i, c]) if i < len(team) and c in team.columns else "(없음)"
        if a != b:
            diff.append((df.at[i, "id"] if i < len(df) else i, c, a, b))
if diff:
    print(f"✖ 팀 엑셀과 다른 칸 {len(diff)}개:")
    for d in diff[:30]:
        print("  ", d)
    sys.exit(1)
print(f"✔ 팀 엑셀({TEAM})과 {len(df)}행 x {len(df.columns)}열 모두 일치")
