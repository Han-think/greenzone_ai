"""2단계: 그린존 후보지 합격/불합격 판정 (필요조건 3가지)

조건 (모두 만족해야 합격)
  ① 보호구역 제외 : 어린이·노인·장애인 보호구역 대상시설 반경 PROTECT_R m 안이면 불합격
  ② 부지 확보     : 공원 또는 공영주차장 (어린이공원은 '조건부'로 표시하고 합격 처리)
                    ※ 공터는 이번 데이터에 위치 정보가 없어 미반영
  ③ 수거차 진입   : 5t 수거차가 양방향 통행한다고 가정
                    등록 폭 >= 7m 이거나 min(등록,실측) >= 7m → 합격 (안정 기준)
                    6m <= min(등록,실측) < 7m          → 조건부 합격 (최소 기준만 충족)
                    그 외                              → 불합격
                    노상주차장은 도로 위 주차면만큼(PARK_LANE_M) 폭을 빼고 판정

입력 (raw/)
  child.csv    전국어린이보호구역표준데이터
  elder.csv    전국노인장애인보호구역표준데이터 (양천구)
  park.csv     전국도시공원정보표준데이터
  parking.csv  전국주차장정보표준데이터
  emap/11470/TL_SPRD_MANAGE.shp  도로명주소 전자지도 도로구간 (양천구, ROAD_BT = 도로폭)
  shinwol1_boundary_5186.geojson (01_boundary.py 결과)

출력 (web/)  ※ 모두 WGS84(EPSG:4326) GeoJSON — Leaflet에 바로 올릴 수 있음
  greenzone_candidates_all.geojson    후보 전체 + 조건별 판정·사유
  greenzone_candidates_pass.geojson   합격(조건부 포함)만
  protection_zones.geojson            보호구역 대상시설 반경 원 (제외 영역)
  protection_facilities.geojson       보호구역 대상시설 점
  roads_shinwol1.geojson              신월1동 주변 도로 + 폭 등급
  shinwol1_boundary.geojson           신월1동 경계
  greenzone_candidates_all.csv        같은 내용 표 (엑셀 확인용)
  screening_map.png                   확인용 지도
"""
import os
import pandas as pd
import geopandas as gpd

# ---- 판정 기준 (팀 합의값, 바꾸면 결과가 다시 계산됨) ----------------------
PROTECT_R = 200       # 보호구역 판정 반경 (m)
ROAD_SAFE = 7.0       # 양방향 5t 수거차 안정 기준 도로폭 (m)
ROAD_MIN = 7.0        # 최소 기준 도로폭 (m) - 팀 결정: 최소 7m (6~7m 조건부 없음)
ROAD_SEARCH = 40      # 후보 좌표(부지 중심)에서 접한 도로로 볼 거리 (m)
PARK_LANE_M = 2.5     # 노상주차장이 차지하는 도로 폭 (주차면 폭)
MIN_AREA_M2 = 20      # 거점 설치 최소 면적 (m2)
M2_PER_STALL = 12.5   # 주차 1면 면적 (2.5m x 5.0m)
EDGE_M = 0            # 후보는 신월1동 경계 안만 (타깃 범위). 보호시설은 경계 밖도 반영
REGISTERED_OK = True  # 등록 도로폭이 안정 기준(7m) 이상이면 실측과 관계없이 도로 조건 합격
CRS_M = 5186          # 거리 계산용 좌표계 (미터)
# --------------------------------------------------------------------------

dong = gpd.read_file("build/shinwol1_boundary_5186.geojson").to_crs(CRS_M).geometry.iloc[0]
area = dong.buffer(600)


def load_points(path):
    for enc in ("cp949", "utf-8-sig"):
        try:
            d = pd.read_csv(path, encoding=enc, dtype=str)
            break
        except UnicodeDecodeError:
            continue
    lon = pd.to_numeric(d["경도"], errors="coerce")
    lat = pd.to_numeric(d["위도"], errors="coerce")
    g = gpd.GeoDataFrame(d, geometry=gpd.points_from_xy(lon, lat), crs=4326).to_crs(CRS_M)
    return g[g.within(area)].copy()


# ① 보호구역 대상시설 -------------------------------------------------------
child = load_points("data/raw/child.csv")
child = gpd.GeoDataFrame({"구분": "어린이보호구역", "시설명": child["대상시설명"],
                          "시설종류": child["시설종류"], "주소": child["소재지지번주소"].fillna(child["소재지도로명주소"]),
                          "geometry": child.geometry}, crs=CRS_M)
elder = load_points("data/raw/elder.csv")
elder = gpd.GeoDataFrame({"구분": "노인·장애인보호구역", "시설명": elder["대상시설명"],
                          "시설종류": "노인·장애인시설", "주소": elder["소재지도로명주소"],
                          "geometry": elder.geometry}, crs=CRS_M)
prot = pd.concat([child, elder], ignore_index=True)
prot = gpd.GeoDataFrame(prot, crs=CRS_M)

# ② 부지 후보 (공원 + 공영주차장) ------------------------------------------
park = load_points("data/raw/park.csv")
parking = load_points("data/raw/parking.csv")
parking = parking[parking["주차장구분"] == "공영"]
c_park = pd.DataFrame({"부지유형": "공원", "이름": park["공원명"] + "공원", "세부유형": park["공원구분"],
                       "주소": park["소재지지번주소"], "면적_m2": pd.to_numeric(park["공원면적"], errors="coerce"),
                       "면적근거": "공원면적(표준데이터)", "geometry": park.geometry})
stalls = pd.to_numeric(parking["주차구획수"], errors="coerce")
c_lot = pd.DataFrame({"부지유형": "공영주차장", "이름": parking["주차장명"] + " 공영주차장",
                      "세부유형": parking["주차장유형"], "주소": parking["소재지지번주소"],
                      "면적_m2": stalls * M2_PER_STALL, "면적근거": f"주차구획수x{M2_PER_STALL}m2 추정",
                      "geometry": parking.geometry})
cand = gpd.GeoDataFrame(pd.concat([c_park, c_lot], ignore_index=True), crs=CRS_M)
cand["경계까지_m"] = cand.distance(dong).round(0)
cand = cand[cand["경계까지_m"] <= EDGE_M].copy()
cand["위치"] = cand["경계까지_m"].map(lambda d: "신월1동 내" if d == 0 else "경계 인접")

# ③ 도로 ----------------------------------------------------------------------
roads = gpd.read_file("data/raw/emap/11470/TL_SPRD_MANAGE.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
roads = roads[roads.intersects(area)].copy()
roads["ROAD_BT"] = pd.to_numeric(roads["ROAD_BT"], errors="coerce")
rw = gpd.read_file("data/raw/emap/11470/TL_SPRD_RW.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
rw = rw[rw.intersects(area)]
from shapely.geometry import LineString, Point
from shapely.ops import unary_union
import numpy as np


def measured_width(line, pt, span=20, step=5, half=40):
    """실폭도로 면(TL_SPRD_RW)을 도로 중심선에 수직으로 잘라 실제 폭을 잰다.
    후보 위치에서 가장 가까운 중심선 지점 앞뒤 span m 범위를 step m 간격으로 재고 중앙값을 쓴다."""
    if line.geom_type == "MultiLineString":
        line = min(line.geoms, key=lambda g: g.distance(pt))
    s0 = line.project(pt)
    local = unary_union(rw[rw.intersects(pt.buffer(span + half))].geometry)
    if local.is_empty:
        return None
    ws = []
    for s in np.arange(s0 - span, s0 + span + 0.1, step):
        if s < 1 or s > line.length - 1:
            continue
        a, b = line.interpolate(s - 1), line.interpolate(s + 1)
        dx, dy = b.x - a.x, b.y - a.y
        n = (dx * dx + dy * dy) ** 0.5
        if n == 0:
            continue
        c = line.interpolate(s)
        px, py = -dy / n * half, dx / n * half
        cut = LineString([(c.x - px, c.y - py), (c.x + px, c.y + py)]).intersection(local)
        parts = getattr(cut, "geoms", [cut])
        hit = [g for g in parts if g.length > 0 and g.distance(c) < 0.5]
        if hit:
            ws.append(hit[0].length)
    return round(float(np.median(ws)), 1) if ws else None

# ---- 판정 -------------------------------------------------------------------
rows = []
for _, c in cand.iterrows():
    r = {}
    # ①
    d = prot.distance(c.geometry)
    i = d.idxmin()
    r["최근접_보호시설"] = f"{prot.at[i, '시설명']}({prot.at[i, '구분']})"
    r["보호시설까지_m"] = int(round(d.min()))
    in_zone = prot[d <= PROTECT_R]
    r["c1_보호구역"] = "불합격" if len(in_zone) else "합격"
    r["c1_사유"] = (f"{', '.join(in_zone['시설명'])} 반경 {PROTECT_R}m 안 (최근접 {r['보호시설까지_m']}m)"
                   if len(in_zone) else f"반경 {PROTECT_R}m 안 보호시설 없음 (최근접 {r['최근접_보호시설']} {r['보호시설까지_m']}m)")
    # ②
    is_child_park = c["세부유형"] == "어린이공원"
    if pd.isna(c["면적_m2"]) or c["면적_m2"] < MIN_AREA_M2:
        r["c2_부지"], r["c2_사유"] = "불합격", f"면적 {c['면적_m2']}m2 < {MIN_AREA_M2}m2"
    elif is_child_park:
        r["c2_부지"], r["c2_사유"] = "조건부", f"어린이공원 {c['면적_m2']:,.0f}m2 - 놀이공간과 분리된 도로변 가장자리에만 설치"
    else:
        r["c2_부지"], r["c2_사유"] = "합격", f"{c['부지유형']}({c['세부유형']}) {c['면적_m2']:,.0f}m2 ({c['면적근거']})"
    # ③
    rd = roads.distance(c.geometry)
    near = roads[rd <= ROAD_SEARCH]
    on_street = c["부지유형"] == "공영주차장" and c["세부유형"] == "노상"
    if len(near) == 0:
        r["접도_도로"], r["접도거리_m"], r["등록폭_m"], r["실측폭_m"], r["유효폭_m"] = "", None, None, None, None
        r["c3_도로"], r["c3_사유"] = "판정불가", f"{ROAD_SEARCH}m 안 도로 데이터 없음 (양천구 전자지도 범위 밖)"
    else:
        if on_street:   # 노상주차장은 자신이 놓인 도로(가장 가까운 도로)로 판정
            near = roads.loc[[rd.idxmin()]]
        opts = []
        for j, rr in near.iterrows():
            bt = float(rr["ROAD_BT"])
            mw = measured_width(rr.geometry, c.geometry)
            lane = PARK_LANE_M if on_street else 0
            eff_reg = bt - lane                                       # 등록폭 기준
            eff_cons = (min(bt, mw) if mw is not None else bt) - lane  # 보수적: 등록·실측 중 작은 값
            if REGISTERED_OK and eff_reg >= ROAD_SAFE:
                eff, basis = eff_reg, "등록폭 기준"                     # 등록폭 7m 이상이면 합격에 포함
            else:
                eff, basis = eff_cons, "등록·실측 중 작은 값"
            opts.append((eff, j, bt, mw, basis))
        eff, j, bt, mw, basis = max(opts, key=lambda t: t[0])   # 접한 도로 중 가장 넓은 쪽을 진입로로 봄
        r["접도_도로"] = roads.at[j, "RN"]
        r["접도거리_m"] = int(round(rd[j]))
        r["등록폭_m"], r["실측폭_m"], r["유효폭_m"], r["폭_판정근거"] = bt, mw, round(eff, 1), basis
        src = f"등록 {bt:g}m / 실측 {mw:g}m" if mw is not None else f"등록 {bt:g}m / 실측 불가"
        note = f", 노상주차면 {PARK_LANE_M}m 제외" if on_street else ""
        txt = f"{r['접도_도로']}({r['접도거리_m']}m 거리, {src}{note}, {basis}) → 유효 {eff:g}m"
        checks = []
        if r["접도거리_m"] > 20:
            checks.append("부지가 이 도로에 실제로 접하는지 로드뷰 확인")
        if basis == "등록폭 기준" and mw is not None and mw - lane < ROAD_SAFE:
            checks.append(f"실측 폭 {mw - lane:g}m로 등록 폭보다 좁음 - 불법주차·도로 상태 로드뷰 확인")
        r["확인필요"] = " / ".join(checks)
        if eff >= ROAD_SAFE:
            r["c3_도로"], r["c3_사유"] = "합격", f"{txt} ≥ 안정 {ROAD_SAFE:g}m"
        elif eff >= ROAD_MIN:
            r["c3_도로"], r["c3_사유"] = "조건부", f"{txt}: 최소 {ROAD_MIN:g}m 충족, 안정 {ROAD_SAFE:g}m 미달"
        else:
            r["c3_도로"], r["c3_사유"] = "불합격", f"{txt} < 최소 {ROAD_MIN:g}m"
    # 종합
    st = [r["c1_보호구역"], r["c2_부지"], r["c3_도로"]]
    if "불합격" in st:
        r["최종판정"] = "불합격"
    elif "판정불가" in st:
        r["최종판정"] = "판정불가"
    elif "조건부" in st:
        r["최종판정"] = "조건부 합격"
    else:
        r["최종판정"] = "합격"
    fails = [n for n, s in zip(["보호구역", "부지", "도로폭"], st) if s in ("불합격", "판정불가")]
    conds = [n for n, s in zip(["어린이공원", "", "도로폭 6~7m"], st) if s == "조건부" and n]
    r["판정요약"] = ("탈락: " + ", ".join(fails)) if fails else (("조건: " + ", ".join(conds)) if conds else "모든 조건 충족")
    rows.append(r)

res = pd.concat([cand.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
res = gpd.GeoDataFrame(res, crs=CRS_M)
order = {"합격": 0, "조건부 합격": 1, "판정불가": 2, "불합격": 3}
res = res.sort_values(["최종판정", "위치", "이름"], key=lambda s: s.map(order) if s.name == "최종판정" else s).reset_index(drop=True)
res.insert(0, "id", [f"GZ{i:02d}" for i in range(1, len(res) + 1)])
w = res.to_crs(4326)
res["위도"], res["경도"] = w.geometry.y.round(6), w.geometry.x.round(6)

# ---- 저장 -------------------------------------------------------------------
os.makedirs("build/web", exist_ok=True)
cols = ["id", "최종판정", "판정요약", "이름", "부지유형", "세부유형", "위치", "주소", "면적_m2",
        "c1_보호구역", "c1_사유", "c2_부지", "c2_사유", "c3_도로", "c3_사유",
        "접도_도로", "접도거리_m", "등록폭_m", "실측폭_m", "유효폭_m", "폭_판정근거", "확인필요", "최근접_보호시설", "보호시설까지_m", "위도", "경도"]
res[cols].to_csv("build/web/greenzone_candidates_all.csv", index=False, encoding="utf-8-sig")
res[cols + ["geometry"]].to_crs(4326).to_file("build/web/greenzone_candidates_all.geojson", driver="GeoJSON")
ok = res[res["최종판정"].isin(["합격", "조건부 합격"])]
ok[cols + ["geometry"]].to_crs(4326).to_file("build/web/greenzone_candidates_pass.geojson", driver="GeoJSON")

pz = prot.copy()
pz["반경_m"] = PROTECT_R
pz["geometry"] = prot.buffer(PROTECT_R)
pz.to_crs(4326).to_file("build/web/protection_zones.geojson", driver="GeoJSON")
prot.to_crs(4326).to_file("build/web/protection_facilities.geojson", driver="GeoJSON")

rclip = roads[roads.intersects(dong.buffer(150))][["RN", "ROAD_BT", "ROA_CLS_SE", "geometry"]].copy()
if ROAD_MIN < ROAD_SAFE:
    rclip["폭등급"] = pd.cut(rclip["ROAD_BT"], [-1, ROAD_MIN - 1e-9, ROAD_SAFE - 1e-9, 999],
                           labels=[f"{ROAD_MIN:g}m 미만", f"{ROAD_MIN:g}~{ROAD_SAFE:g}m", f"{ROAD_SAFE:g}m 이상"]).astype(str)
else:
    rclip["폭등급"] = pd.cut(rclip["ROAD_BT"], [-1, ROAD_SAFE - 1e-9, 999],
                           labels=[f"{ROAD_SAFE:g}m 미만", f"{ROAD_SAFE:g}m 이상"]).astype(str)
rclip.rename(columns={"RN": "도로명", "ROAD_BT": "도로폭_m", "ROA_CLS_SE": "도로위계"}).to_crs(4326).to_file(
    "build/web/roads_shinwol1.geojson", driver="GeoJSON")
gpd.GeoDataFrame({"name": ["서울특별시 양천구 신월1동"]}, geometry=[dong], crs=CRS_M).to_crs(4326).to_file(
    "build/web/shinwol1_boundary.geojson", driver="GeoJSON")

print(res["최종판정"].value_counts().to_string())
print(res[["id", "최종판정", "이름", "세부유형", "위치", "c1_보호구역", "c2_부지", "c3_도로", "접도_도로", "등록폭_m", "실측폭_m", "유효폭_m"]].to_string(index=False))
print("도로 폭 분포(신월1동 주변):", rclip["폭등급"].value_counts().to_dict())

# ---- 확인용 지도 -------------------------------------------------------------
import logging
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
for f in font_manager.findSystemFonts():
    if any(k in f for k in ("NotoSansCJK", "malgun", "Malgun", "Nanum", "AppleGothic")):
        font_manager.fontManager.addfont(f)
names = {f.name for f in font_manager.fontManager.ttflist}
plt.rcParams["font.family"] = next((n for n in ("Malgun Gothic", "AppleGothic", "Noto Sans CJK KR", "NanumGothic") if n in names), "sans-serif")

fig, ax = plt.subplots(figsize=(9, 10))
pz.plot(ax=ax, color="#f3c2bb", alpha=0.5, linewidth=0)
rc = {f"{ROAD_MIN:g}m 미만": ("#c9c9c9", 0.8), f"{ROAD_MIN:g}~{ROAD_SAFE:g}m": ("#e0a030", 1.8), f"{ROAD_SAFE:g}m 이상": ("#2f6db5", 2.6)}
for k, (col, lw) in rc.items():
    rclip[rclip["폭등급"] == k].plot(ax=ax, color=col, linewidth=lw)
gpd.GeoSeries([dong], crs=CRS_M).boundary.plot(ax=ax, color="#1b6b4a", linewidth=2.2)
prot.plot(ax=ax, color="#b3261e", marker="^", markersize=40)
pc = {"합격": "#1b8a4a", "조건부 합격": "#f2b705", "판정불가": "#8a8a8a", "불합격": "#d64541"}
for k, col in pc.items():
    s = res[res["최종판정"] == k]
    if len(s):
        s.plot(ax=ax, color=col, markersize=110, edgecolor="black", linewidth=0.8, zorder=5)
for _, r in res.iterrows():
    ax.annotate(f"{r['id']} {r['이름']}", (r.geometry.x, r.geometry.y), xytext=(7, 4), textcoords="offset points", fontsize=7.5, zorder=6)
minx, miny, maxx, maxy = dong.buffer(170).bounds
ax.set_xlim(minx, maxx); ax.set_ylim(miny, maxy); ax.set_axis_off()
ax.legend(handles=[Line2D([], [], marker="o", ls="", color=c, mec="black", ms=9, label=k) for k, c in pc.items()] + [
    Line2D([], [], color=rc[k][0], lw=rc[k][1] + 0.5, label=f"도로폭 {k}") for k in rc] + [
    Line2D([], [], marker="^", ls="", color="#b3261e", ms=8, label="보호구역 대상시설"),
    Line2D([], [], marker="s", ls="", color="#f3c2bb", ms=11, label=f"반경 {PROTECT_R}m 제외 영역")],
    loc="lower left", fontsize=7.5, frameon=True)
ax.set_title("신월1동 그린존 후보지 판정 (보호구역 200m · 공원/공영주차장 · 도로폭 7m/6m)", fontsize=11)
plt.tight_layout()
plt.savefig("build/web/screening_map.png", dpi=160)
