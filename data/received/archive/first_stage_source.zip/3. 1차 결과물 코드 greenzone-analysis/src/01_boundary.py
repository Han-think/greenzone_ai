"""1단계: 행정동 경계에서 양천구 신월1동만 추출

입력: data/raw/HangJeongDong_ver20260701.geojson (vuski/admdongkor, WGS84)
출력 (build/):
  shinwol1_boundary.geojson        - 신월1동 경계 (WGS84, 웹 지도용)
  shinwol1_boundary_5186.geojson   - 신월1동 경계 (EPSG:5186, 미터 단위 분석용)
  shinwol1_buffer500_5186.geojson  - 경계에서 500m 확장한 범위 (주변 시설 추출용)
"""
import sys
import geopandas as gpd

import os
os.makedirs("build", exist_ok=True)
src = sys.argv[1] if len(sys.argv) > 1 else "data/raw/HangJeongDong_ver20260701.geojson"
TARGET = "서울특별시 양천구 신월1동"

gdf = gpd.read_file(src)
dong = gdf[gdf["adm_nm"] == TARGET].copy()
if len(dong) != 1:
    raise SystemExit(f"'{TARGET}' 검색 결과가 {len(dong)}건입니다. adm_nm 값을 확인하세요.")

dong.to_file("build/shinwol1_boundary.geojson", driver="GeoJSON")

dong_m = dong.to_crs(epsg=5186)
dong_m.to_file("build/shinwol1_boundary_5186.geojson", driver="GeoJSON")

buf = dong_m.copy()
buf["geometry"] = dong_m.buffer(500)
buf.to_file("build/shinwol1_buffer500_5186.geojson", driver="GeoJSON")

print(dong.drop(columns="geometry").to_string(index=False))
print(f"면적: {dong_m.area.iloc[0] / 1e6:.4f} km²")
