"""3단계: 도로변 후보 추가 발굴 (공원·공영주차장만으로는 후보가 부족하므로)

넓은 도로 위 지점을 20m 간격으로 훑어서, 아래를 모두 만족하는 곳을 도로변 후보로 추가한다.
  ① 보호구역 : 어린이·노인·장애인 보호구역 대상시설 반경 PROTECT_R m 밖
  ② 도로폭   : 유효폭 >= 7m (등록폭 7m 이상이면 등록폭, 아니면 min(등록, 실측))
               대로(위계 1·2: 고속도로·대로)는 정차가 위험해 제외
               교차로 중심에서 JUNCTION_M m 안은 제외 (모퉁이 5m·횡단보도 10m 정차금지 고려)
  ③ 설치 공간 (둘 중 하나)
      - 공터형 : 건물·도로가 아닌 빈 공간(4m x 5m 이상 들어감)이 도로에 바로 붙어 있음 → 공터 추정
      - 정차형 : 유효폭 >= 9.5m (양방향 7m + 수거차 정차 2.5m) → 도로변에 정차하며 수거 가능
후보끼리는 MIN_SPACING m 이상 떨어지게 고른다 (공터형 우선, 그다음 넓은 도로 우선).
기존 공공부지 후보(02_public_sites.py 결과)와 합쳐 web/ 폴더에 저장한다.

주의: 공터는 '빈 공간 추정'이며 소유(사유지/국공유지)와 실제 용도는 확인하지 않았다.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, LineString
from shapely.ops import unary_union, nearest_points

# ---- 기준값 ------------------------------------------------------------------
PROTECT_R = 200
ROAD_SAFE = 7.0
STOP_LANE = 2.5          # 수거차 정차에 필요한 추가 폭
STOP_W = ROAD_SAFE + STOP_LANE
JUNCTION_M = 15          # 교차로 중심 기준 제외 거리
STEP_M = 20              # 도로를 훑는 간격
LOT_SEARCH_M = 8         # 도로 경계에서 공터까지 허용 거리
LOT_OPEN_M = 2.0         # 폭 4m(=2m x 2) 미만 틈은 공터로 보지 않음
LOT_MIN_M2 = 20          # 공터 최소 면적 (4m x 5m)
LOT_COMPACT = 0.2        # 골목처럼 가늘고 갈라진 모양 제외 (원=1, 가는 선=0)
MIN_SPACING = 80         # 후보 간 최소 간격
CRS_M = 5186
# ------------------------------------------------------------------------------

dong = gpd.read_file("build/shinwol1_boundary_5186.geojson").to_crs(CRS_M).geometry.iloc[0]
rd_all = gpd.read_file("data/raw/emap/11470/TL_SPRD_MANAGE.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
rd_all = rd_all[rd_all.intersects(dong.buffer(300))].copy()
rd_all["ROAD_BT"] = pd.to_numeric(rd_all["ROAD_BT"], errors="coerce")
rd_all["ROA_CLS_SE"] = rd_all["ROA_CLS_SE"].astype(str)
rw = gpd.read_file("data/raw/emap/11470/TL_SPRD_RW.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
rw = rw[rw.intersects(dong.buffer(300))]
rw_u = unary_union(rw.geometry)
bld = gpd.read_file("data/raw/emap/11470/TL_SPBD_BULD.shp", encoding="cp949").set_crs(5179, allow_override=True).to_crs(CRS_M)
bld_u = unary_union(bld[bld.intersects(dong.buffer(50))].geometry)
prot = gpd.read_file("build/web/protection_facilities.geojson").to_crs(CRS_M)
base = gpd.read_file("build/web/greenzone_candidates_all.geojson").to_crs(CRS_M)

# 공공부지(공원·주차장)는 공터에서 빼서 중복을 막음
public_sites = unary_union(base.geometry.buffer(30))

# 공터 추정: 동 안에서 건물·도로를 뺀 빈 공간 → 폭 4m 미만 틈 제거 → 20㎡ 이상
# 실폭도로 도형에 빠진 골목도 빼기: 모든 도로 중심선을 (등록폭/2 + 0.5m)만큼 넓혀 제거
alley = unary_union([g.buffer(max(bt / 2, 2.0) + 0.5) for g, bt in zip(rd_all.geometry, rd_all["ROAD_BT"].fillna(4))])
free = dong.difference(bld_u).difference(rw_u).difference(alley).difference(public_sites)
free = free.buffer(-LOT_OPEN_M).buffer(LOT_OPEN_M)
def compact(g):                       # 원에 가까우면 1, 가늘게 갈라지면 0에 가까움
    return 4 * np.pi * g.area / (g.length ** 2) if g.length else 0
lots = gpd.GeoDataFrame(geometry=[g for g in getattr(free, "geoms", [free])
                                  if g.area >= LOT_MIN_M2 and compact(g) >= LOT_COMPACT], crs=CRS_M)
lots = lots[lots.distance(rw_u.union(alley)) <= 1.5].reset_index(drop=True)   # 도로에 바로 붙은 것만
lots["면적_m2"] = lots.area.round(0)

# 교차로: 도로구간 끝점 중 다른 구간과 만나는 점
ends = []
for g in rd_all.geometry:
    for part in getattr(g, "geoms", [g]):
        ends += [Point(part.coords[0]), Point(part.coords[-1])]
ends = gpd.GeoSeries(ends, crs=CRS_M)
ends_u = unary_union(rd_all.geometry)
junc = unary_union([p for p in ends if sum(rd_all.distance(p) < 0.5) >= 2])


def measured_width(line, pt, span=10, step=5, half=40):
    if line.geom_type == "MultiLineString":
        line = min(line.geoms, key=lambda g: g.distance(pt))
    s0 = line.project(pt)
    ws = []
    for s in np.arange(s0 - span, s0 + span + 0.1, step):
        if s < 1 or s > line.length - 1:
            continue
        a, b = line.interpolate(s - 1), line.interpolate(s + 1)
        dx, dy = b.x - a.x, b.y - a.y
        n = (dx * dx + dy * dy) ** 0.5
        c = line.interpolate(s)
        px, py = -dy / n * half, dx / n * half
        cut = LineString([(c.x - px, c.y - py), (c.x + px, c.y + py)]).intersection(rw_u)
        hit = [g for g in getattr(cut, "geoms", [cut]) if g.length > 0 and g.distance(c) < 0.5]
        if hit:
            ws.append(hit[0].length)
    return round(float(np.median(ws)), 1) if ws else None


# ---- 도로를 훑으며 후보 지점 평가 ----------------------------------------------
pts = []
for j, r in rd_all.iterrows():
    if r["ROA_CLS_SE"] in ("1", "2"):          # 고속도로·대로 제외
        continue
    for part in getattr(r.geometry, "geoms", [r.geometry]):
        inside = part.intersection(dong)
        for seg in getattr(inside, "geoms", [inside]):
            if seg.is_empty or seg.length < STEP_M:
                continue
            for s in np.arange(STEP_M / 2, seg.length, STEP_M):
                p = seg.interpolate(s)
                pts.append((j, p))

rows = []
for j, p in pts:
    r = rd_all.loc[j]
    bt = float(r["ROAD_BT"])
    if bt < ROAD_SAFE - 1:                     # 계산 절약: 등록폭이 한참 좁은 길은 실측도 생략
        continue
    if p.distance(junc) < JUNCTION_M:
        continue
    dprot = prot.distance(p)
    if dprot.min() <= PROTECT_R:
        continue
    mw = measured_width(r.geometry, p)
    eff = bt if bt >= ROAD_SAFE else (min(bt, mw) if mw is not None else bt)
    if eff < ROAD_SAFE:
        continue
    # 설치 공간
    near_lots = lots[lots.distance(p) <= eff / 2 + LOT_SEARCH_M]
    if len(near_lots):
        k = near_lots.area.idxmax()
        kind, lot_area = "공터형", float(lots.at[k, "면적_m2"])
        site = lots.at[k, "geometry"]
        edge = nearest_points(site, p)[0]                 # 공터 중 도로와 가장 가까운 가장자리
        inner = site.intersection(edge.buffer(3))          # 가장자리에서 3m 안쪽 지점에 표시
        spot = inner.representative_point() if not inner.is_empty else edge
    elif eff >= STOP_W:
        kind, lot_area, spot = "정차형", None, p
    else:
        continue
    i = dprot.idxmin()
    rows.append({"lot_id": int(k) if kind == "공터형" else -1, "road_idx": j, "접도_도로": r["RN"], "등록폭_m": bt, "실측폭_m": mw, "유효폭_m": round(eff, 1),
                 "폭_판정근거": "등록폭 기준" if bt >= ROAD_SAFE else "등록·실측 중 작은 값",
                 "세부유형": kind, "공터면적_m2": lot_area,
                 "최근접_보호시설": f"{prot.at[i, '시설명']}({prot.at[i, '구분']})", "보호시설까지_m": int(round(dprot.min())),
                 "교차로까지_m": int(round(p.distance(junc))), "geometry": spot})

ev = gpd.GeoDataFrame(rows, crs=CRS_M)
import os
os.makedirs("build/work", exist_ok=True)
ev.to_file("build/work/roadside_all_points.geojson", driver="GeoJSON")      # 04_select_candidates.py에서 사용
lots.assign(lot_id=lots.index).to_file("build/work/open_space_all.geojson", driver="GeoJSON")
print("조건 통과 지점:", len(ev), ev["세부유형"].value_counts().to_dict() if len(ev) else {})

# ---- 간격 두고 고르기 (공터형 우선 → 넓은 도로 우선) ------------------------------
keep_geoms = list(base[base["최종판정"].isin(["합격", "조건부 합격"])].geometry)
ev["_p"] = ev["세부유형"].map({"공터형": 0, "정차형": 1})
ev = ev.sort_values(["_p", "유효폭_m", "공터면적_m2"], ascending=[True, False, False])
chosen = []
for idx, r in ev.iterrows():
    if all(r.geometry.distance(g) >= MIN_SPACING for g in keep_geoms):
        chosen.append(idx)
        keep_geoms.append(r.geometry)
new = ev.loc[chosen].drop(columns="_p").reset_index(drop=True)

# ---- 기존 후보와 같은 형식으로 정리 ---------------------------------------------
def c2_text(r):
    if r["세부유형"] == "공터형":
        return f"도로변 빈 공간 약 {r['공터면적_m2']:,.0f}m2 (건물·도로 제외 공간 추정) - 소유·용도 확인 필요"
    return f"도로 유효폭 {r['유효폭_m']:g}m ≥ {STOP_W:g}m (양방향 {ROAD_SAFE:g}m + 정차 {STOP_LANE:g}m) - 도로변 정차 수거"

new["이름"] = new.apply(lambda r: f"{r['접도_도로']} 도로변({r['세부유형']})", axis=1)
new["부지유형"] = "도로변"
new["위치"] = "신월1동 내"
new["주소"] = new["접도_도로"]
new["면적_m2"] = new["공터면적_m2"]
new["c1_보호구역"] = "합격"
new["c1_사유"] = new.apply(lambda r: f"반경 {PROTECT_R}m 안 보호시설 없음 (최근접 {r['최근접_보호시설']} {r['보호시설까지_m']}m)", axis=1)
new["c2_부지"] = "조건부"
new["c2_사유"] = new.apply(c2_text, axis=1)
new["c3_도로"] = "합격"
new["c3_사유"] = new.apply(lambda r: f"{r['접도_도로']}(등록 {r['등록폭_m']:g}m / 실측 {r['실측폭_m'] if r['실측폭_m'] is not None else '불가'}m, {r['폭_판정근거']}) → 유효 {r['유효폭_m']:g}m ≥ 안정 {ROAD_SAFE:g}m, 교차로에서 {r['교차로까지_m']}m", axis=1)
new["접도거리_m"] = 0
new["최종판정"] = "조건부 합격"
new["판정요약"] = new["세부유형"].map({"공터형": "조건: 공터 소유·용도 확인", "정차형": "조건: 정차 허용·보도 폭 확인"})
new["확인필요"] = new.apply(lambda r: ("빈 공간이 사유지 마당·주차장인지 로드뷰 확인" if r["세부유형"] == "공터형"
                                    else "주정차 금지 표시·버스정류장·횡단보도 여부 로드뷰 확인")
                                   + (f" / 실측 폭 {r['실측폭_m']:g}m로 등록 폭보다 좁음" if r["실측폭_m"] is not None and r["실측폭_m"] < ROAD_SAFE else ""), axis=1)
new["후보군"] = "도로변"
base["후보군"] = "공공부지"
base["공터면적_m2"] = None
base["교차로까지_m"] = None

all_ = pd.concat([base, new], ignore_index=True)
all_ = gpd.GeoDataFrame(all_, crs=CRS_M)
order = {"합격": 0, "조건부 합격": 1, "판정불가": 2, "불합격": 3}
all_["_o"] = all_["최종판정"].map(order)
all_["_g"] = all_["후보군"].map({"공공부지": 0, "도로변": 1})
all_ = all_.sort_values(["_o", "_g", "이름"]).drop(columns=["_o", "_g"]).reset_index(drop=True)
all_["id"] = [f"GZ{i:02d}" for i in range(1, len(all_) + 1)]
w = all_.to_crs(4326)
all_["위도"], all_["경도"] = w.geometry.y.round(6), w.geometry.x.round(6)

cols = ["id", "최종판정", "판정요약", "후보군", "이름", "부지유형", "세부유형", "위치", "주소", "면적_m2",
        "c1_보호구역", "c1_사유", "c2_부지", "c2_사유", "c3_도로", "c3_사유",
        "접도_도로", "접도거리_m", "등록폭_m", "실측폭_m", "유효폭_m", "폭_판정근거", "교차로까지_m", "확인필요",
        "최근접_보호시설", "보호시설까지_m", "위도", "경도"]
all_[cols].to_csv("build/web/greenzone_candidates_all.csv", index=False, encoding="utf-8-sig")
all_[cols + ["geometry"]].to_crs(4326).to_file("build/web/greenzone_candidates_all.geojson", driver="GeoJSON")
ok = all_[all_["최종판정"].isin(["합격", "조건부 합격"])]
ok[cols + ["geometry"]].to_crs(4326).to_file("build/web/greenzone_candidates_pass.geojson", driver="GeoJSON")
used = lots[lots.distance(unary_union(new[new["세부유형"] == "공터형"].geometry)) < 0.5] if (new["세부유형"] == "공터형").any() else lots.iloc[0:0]
used.assign(구분="공터 추정(건물·도로 제외 빈 공간)").to_crs(4326).to_file("build/web/open_space_estimated.geojson", driver="GeoJSON")

print(all_.groupby(["후보군", "최종판정"]).size().to_string())
print(new[["접도_도로", "세부유형", "등록폭_m", "실측폭_m", "유효폭_m", "공터면적_m2", "보호시설까지_m", "교차로까지_m"]].to_string())

# ---- 확인용 지도 -------------------------------------------------------------
import logging
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
for f in font_manager.findSystemFonts():
    if any(k in f for k in ("NotoSansCJK", "malgun", "Malgun", "Nanum", "AppleGothic")):
        font_manager.fontManager.addfont(f)
names = {f.name for f in font_manager.fontManager.ttflist}
plt.rcParams["font.family"] = next((n for n in ("Malgun Gothic", "AppleGothic", "Noto Sans CJK KR", "NanumGothic") if n in names), "sans-serif")

roads_web = gpd.read_file("build/web/roads_shinwol1.geojson").to_crs(CRS_M)
pz = gpd.read_file("build/web/protection_zones.geojson").to_crs(CRS_M)
fig, ax = plt.subplots(figsize=(9, 10))
pz.plot(ax=ax, color="#f3c2bb", alpha=0.5, linewidth=0)
for k, (col, lw) in {"7m 미만": ("#d0d0d0", 0.7), "7m 이상": ("#2f6db5", 2.4)}.items():
    roads_web[roads_web["폭등급"] == k].plot(ax=ax, color=col, linewidth=lw)
if len(used):
    used.plot(ax=ax, color="#8fd19e", edgecolor="#2e7d32", linewidth=0.6)
gpd.GeoSeries([dong], crs=CRS_M).boundary.plot(ax=ax, color="#1b6b4a", linewidth=2.2)
prot.plot(ax=ax, color="#b3261e", marker="^", markersize=36)
sty = [("공공부지", "합격", "#1b8a4a", "o"), ("공공부지", "조건부 합격", "#f2b705", "o"), ("공공부지", "불합격", "#d64541", "o"),
       ("도로변", "공터형", "#7b3fb5", "D"), ("도로변", "정차형", "#0aa3a3", "s")]
for grp, key, col, mk in sty:
    s = all_[(all_["후보군"] == grp) & ((all_["최종판정"] == key) if grp == "공공부지" else (all_["세부유형"] == key))]
    if len(s):
        s.plot(ax=ax, color=col, marker=mk, markersize=95, edgecolor="black", linewidth=0.8, zorder=5)
for _, r in all_.iterrows():
    ax.annotate(r["id"], (r.geometry.x, r.geometry.y), xytext=(6, 4), textcoords="offset points", fontsize=7.5, zorder=6)
minx, miny, maxx, maxy = dong.buffer(120).bounds
ax.set_xlim(minx, maxx); ax.set_ylim(miny, maxy); ax.set_axis_off()
ax.legend(handles=[Line2D([], [], marker=mk, ls="", color=col, mec="black", ms=9,
                          label=(f"공공부지 {key}" if grp == "공공부지" else f"도로변 {key} (조건부)")) for grp, key, col, mk in sty] + [
    Line2D([], [], marker="s", ls="", color="#8fd19e", ms=10, label="공터 추정 공간"),
    Line2D([], [], color="#2f6db5", lw=2.4, label="도로폭 7m 이상"),
    Line2D([], [], marker="s", ls="", color="#f3c2bb", ms=10, label=f"보호구역 반경 {PROTECT_R}m")],
    loc="lower left", fontsize=7.5, frameon=True)
ax.set_title("신월1동 그린존 후보군 (공공부지 + 도로변 공터형·정차형)", fontsize=11)
plt.tight_layout()
plt.savefig("build/web/screening_map.png", dpi=160)
