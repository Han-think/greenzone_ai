"""그린존 1차 후보군 분석 전체 실행

저장소 최상위 폴더에서 실행:  python run_all.py
필요한 원본 데이터가 data/raw/ 에 있는지 먼저 확인한 뒤, src/ 의 단계를 순서대로 실행한다.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT)

REQUIRED = [
    "data/raw/HangJeongDong_ver20260701.geojson",
    "data/raw/child.csv",
    "data/raw/elder.csv",
    "data/raw/park.csv",
    "data/raw/parking.csv",
    "data/raw/emap/11470/TL_SPRD_MANAGE.shp",
    "data/raw/emap/11470/TL_SPRD_RW.shp",
    "data/raw/emap/11470/TL_SPBD_BULD.shp",
    "data/team/greenzone_1st.xlsx",
    "data/team/manual_edits.csv",
]
STEPS = [
    "src/01_boundary.py",           # 신월1동 경계
    "src/02_public_sites.py",       # 공원·공영주차장 판정 (보호구역·부지·도로폭)
    "src/03_roadside_lots.py",      # 도로변 공터 후보 탐색
    "src/04_select_candidates.py",  # 1차 후보 확정 (15곳 → 팀 결정 반영 11곳)
    "src/05_team_table.py",         # 팀 수동 수정 적용 → 팀 엑셀과 한 칸씩 대조 검증
    "src/06_greenzone1st.py",       # 팀 엑셀 기준 최종 결과물 (geojson·csv·html·png)
    "src/07_greenzone1st_md.py",    # 설명 문서
]

missing = [p for p in REQUIRED if not os.path.exists(p)]
if missing:
    print("다음 원본 데이터가 없습니다. data/README.md 를 보고 내려받아 주세요.")
    for p in missing:
        print("  -", p)
    sys.exit(1)

for step in STEPS:
    print(f"\n▶ {step}")
    r = subprocess.run([sys.executable, step])
    if r.returncode != 0:
        print(f"\n✖ {step} 에서 멈췄습니다.")
        sys.exit(r.returncode)
print("\n✔ 완료: outputs/greenzone1st/ 를 확인하세요.")
